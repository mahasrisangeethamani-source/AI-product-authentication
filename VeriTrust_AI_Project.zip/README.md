# VeriTrust AI — Product Authentication Dashboard

A frontend dashboard inspired by the supplied reference, with a separate Express backend API.

## Folder structure
- `frontend/index.html` — dashboard markup
- `frontend/style.css` — responsive dark pink styling
- `frontend/app.js` — frontend logic and API connection
- `backend/server.js` — REST API and serial verification logic
- `backend/package.json` — backend dependencies
- `backend/data/db.json` — local demo data (created automatically if missing)
- `backend/uploads/` — uploaded product images

## Run in VS Code
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP and open the `veritrust_project` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```bash
   cd backend
   npm install
   npm start
   ```
5. Keep the terminal running. You should see `VeriTrust API running at http://localhost:5000`.
6. Open `frontend/index.html` in a browser (Live Server extension is recommended).

The frontend uses `http://localhost:5000/api` by default. The API health check is `http://localhost:5000/api/health`.

## Demo serial numbers
- `A1B2C3-15` — Authentic
- `X9Z8Y7-22` — Counterfeit (demo flagged)
- `Q7W6E5-11` — Authentic
- `L3K2J1-08` — Authentic
- `M4N3B2-77` — Counterfeit (demo flagged)
- Any unknown serial — Counterfeit / unregistered

Register a product with the dashboard's **Register Product** quick action; then verify its serial number.

## Deploying
Deploy `backend/` to a Node.js host (for example Render or Railway) and set its `PORT` environment variable if required. For a hosted frontend, change the `API_BASE` value at the top of `frontend/app.js` to your deployed backend URL ending in `/api`, then redeploy the frontend. Configure CORS restrictions before production use.

## Important limitation
This is a working academic demo based on registered serial numbers, not a trained AI/CNN model. The displayed “Authentic/Counterfeit” result is determined by the demo serial-number registry and flagged demo records; uploaded images are stored but are not currently analyzed by an AI model. Do not use for real commercial authentication without a validated model, secure database, and production security controls.
