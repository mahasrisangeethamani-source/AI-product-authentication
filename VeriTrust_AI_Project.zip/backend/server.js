const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 5000;
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");
fs.mkdirSync(DATA_DIR,{recursive:true}); fs.mkdirSync(UPLOAD_DIR,{recursive:true});
const DB_FILE = path.join(DATA_DIR,"db.json");
const initial = {
  products: [
    {id:1,productName:"Nike Air Max",serialCode:"A1B2C3-15",brand:"Nike",imageUrl:"",createdAt:new Date().toISOString()},
    {id:2,productName:"Leather Handbag",serialCode:"X9Z8Y7-22",brand:"VeriTrust demo",imageUrl:"",createdAt:new Date().toISOString()},
    {id:3,productName:"Smartphone",serialCode:"Q7W6E5-11",brand:"VeriTrust demo",imageUrl:"",createdAt:new Date().toISOString()},
    {id:4,productName:"Smart Watch",serialCode:"L3K2J1-08",brand:"VeriTrust demo",imageUrl:"",createdAt:new Date().toISOString()},
    {id:5,productName:"Sports Shoes",serialCode:"M4N3B2-77",brand:"VeriTrust demo",imageUrl:"",createdAt:new Date().toISOString()}
  ],
  history: [
    {id:1,productName:"Nike Air Max",serialCode:"A1B2C3-15",result:"Authentic",imageUrl:"",createdAt:"2026-10-11T11:45:00.000Z"},
    {id:2,productName:"Leather Handbag",serialCode:"X9Z8Y7-22",result:"Counterfeit",imageUrl:"",createdAt:"2026-10-11T10:32:00.000Z"},
    {id:3,productName:"Smartphone",serialCode:"Q7W6E5-11",result:"Authentic",imageUrl:"",createdAt:"2026-10-11T09:18:00.000Z"},
    {id:4,productName:"Smart Watch",serialCode:"L3K2J1-08",result:"Authentic",imageUrl:"",createdAt:"2026-10-11T08:07:00.000Z"},
    {id:5,productName:"Sports Shoes",serialCode:"M4N3B2-77",result:"Counterfeit",imageUrl:"",createdAt:"2026-10-11T07:21:00.000Z"}
  ],
  alerts: [
    {id:1,type:"danger",message:"Counterfeit product detected",createdAt:"2026-10-11T10:32:00.000Z"},
    {id:2,type:"warning",message:"Unusual scan pattern detected",createdAt:"2026-10-11T09:15:00.000Z"},
    {id:3,type:"success",message:"New product registered",createdAt:"2026-10-11T08:45:00.000Z"}
  ]
};
if(!fs.existsSync(DB_FILE))fs.writeFileSync(DB_FILE,JSON.stringify(initial,null,2));
function readDB(){return JSON.parse(fs.readFileSync(DB_FILE,"utf8"))}
function writeDB(db){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2))}
app.use(cors()); app.use(express.json()); app.use("/uploads",express.static(UPLOAD_DIR));
const storage=multer.diskStorage({destination:UPLOAD_DIR,filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp)$/.test(file.mimetype))});
app.get("/api/health",(req,res)=>res.json({status:"ok",service:"VeriTrust AI API"}));
app.get("/api/stats",(req,res)=>{const db=readDB(),totalScans=db.history.length,authenticCount=db.history.filter(x=>x.result==="Authentic").length,counterfeitCount=totalScans-authenticCount;const authenticPercent=totalScans?Math.round(authenticCount/totalScans*100):0;res.json({totalScans,authenticCount,counterfeitCount,detectionRate:authenticPercent,authenticPercent,counterfeitPercent:100-authenticPercent})});
app.get("/api/history",(req,res)=>res.json(readDB().history.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))));
app.get("/api/alerts",(req,res)=>res.json(readDB().alerts.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))));
app.get("/api/products",(req,res)=>res.json(readDB().products));
app.post("/api/products",(req,res)=>{const {serialCode,productName,brand=""}=req.body||{};if(!serialCode||!productName)return res.status(400).json({message:"serialCode and productName are required"});const db=readDB();if(db.products.some(p=>p.serialCode.toLowerCase()===String(serialCode).toLowerCase()))return res.status(409).json({message:"Serial number is already registered"});const product={id:Date.now(),serialCode:String(serialCode).trim(),productName:String(productName).trim(),brand:String(brand),imageUrl:"",createdAt:new Date().toISOString()};db.products.push(product);db.alerts.unshift({id:Date.now(),type:"success",message:"New product registered: "+product.productName,createdAt:new Date().toISOString()});writeDB(db);res.status(201).json({message:"Product registered",product})});
app.post("/api/verify",upload.single("image"),(req,res)=>{const serialCode=String(req.body.serialCode||"").trim();if(!serialCode)return res.status(400).json({message:"serialCode is required"});const db=readDB();const product=db.products.find(p=>p.serialCode.toLowerCase()===serialCode.toLowerCase());const authentic=!!product && product.serialCode.toLowerCase()!=="x9z8y7-22" && product.serialCode.toLowerCase()!=="m4n3b2-77";const result=authentic?"Authentic":"Counterfeit";const imageUrl=req.file?"/uploads/"+req.file.filename:(product?.imageUrl||"");const entry={id:Date.now(),productName:product?.productName||"Unknown Product",serialCode,result,imageUrl,createdAt:new Date().toISOString()};db.history.unshift(entry);if(!authentic)db.alerts.unshift({id:Date.now()+1,type:"danger",message:"Counterfeit or unregistered product detected: "+serialCode,createdAt:new Date().toISOString()});writeDB(db);res.json({result,productName:entry.productName,serialCode,message:authentic?"Registered serial number matched.":"Serial number is not trusted or is flagged in demo data.",product:product||null,scan:entry})});
app.use((err,req,res,next)=>{console.error(err);res.status(400).json({message:err.message||"Request failed"})});
app.listen(PORT,()=>console.log(`VeriTrust API running at http://localhost:${PORT}`));